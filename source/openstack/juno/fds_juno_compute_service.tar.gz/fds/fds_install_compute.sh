#!/bin/bash
if [ $# -eq 1 ]; then
    PIP_PROXY="--proxy=$1"
else
    PIP_PROXY=""
fi

## Download required packages
echo apt-get -y install nbd-client gcc python-pip python-dev
apt-get -y install nbd-client gcc python-pip python-dev

echo pip $PIP_PROXY install psutil
pip $PIP_PROXY install psutil

BIN_DIR=/usr/sbin
DRIVER_DIR=$PWD
INITRC=/etc/init/
FDS_NBD_SVC=nova-compute-fds-nbdadmd
FDS_NBD_SVC_CFG=$FDS_NBD_SVC.conf

## Copy nbd files

echo "Copy NBD service related files"

if [ ! -e $DRIVER_DIR/nbdadm.py ]; then
    echo "FAIL: nbdadm.py not exist"
    exit 1
fi
echo cp $DRIVER_DIR/nbdadm.py $BIN_DIR/
cp $DRIVER_DIR/nbdadm.py $BIN_DIR/

if [ ! -e $DRIVER_DIR/nbdadmd.py ]; then
    echo "FAIL: nbdadmd.py not exist"
    exit 1
fi
echo cp $DRIVER_DIR/nbdadmd.py $BIN_DIR/
cp $DRIVER_DIR/nbdadmd.py $BIN_DIR/

if [ ! -e $DRIVER_DIR/$FDS_NBD_SVC_CFG ]; then
    echo "FAIL: $FDS_NBD_SVC_CFG not exist"
    exit 1
fi

echo cp $DRIVER_DIR/$FDS_NBD_SVC_CFG $INITRC/
cp $DRIVER_DIR/$FDS_NBD_SVC_CFG $INITRC/

echo service $FDS_NBD_SVC start
service $FDS_NBD_SVC start

depmod
modprobe nbd
lsmod | grep nbd
