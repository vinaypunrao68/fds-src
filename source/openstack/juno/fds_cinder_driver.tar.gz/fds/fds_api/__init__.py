from os.path import dirname
import sys
sys.path.append(dirname(__file__))
