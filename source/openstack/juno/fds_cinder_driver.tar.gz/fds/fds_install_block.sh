#!/bin/bash
if [ $# -eq 1 ]; then
    PIP_PROXY="--proxy=$1"
else
    PIP_PROXY=""
fi

## Download required packages

echo apt-get -y install python-pip python-cinderclient nbd-client python-dev
apt-get -y install python-pip python-cinderclient nbd-client python-dev

echo pip $PIP_PROXY install psutil
pip $PIP_PROXY install psutil

echo pip $PIP_PROXY install thrift
pip $PIP_PROXY install thrift

## Install nbd kernel module

modprobe nbd
nbd_found=`lsmod | grep -c nbd`
if [ $nbd_found -ne 1 ]; then
    echo "Failed to modprobe nbd"
    exit 1
fi

## Copying cinder related files:  
#   nbdadm.py -> /usr/sbin
#   fds_common.py -> /usr/lib/python2.7/dist-packages/cinder/volume/drivers
#   fdsnbdd_juno.py -> /usr/lib/python2.7/dist-packages/cinder/volume/drivers
#   fds_api dir -> /usr/lib/python2.7/dist-packages/cinder/volume/drivers


CINDER_DRIVER_DIR=/usr/lib/python2.7/dist-packages/cinder/volume/drivers
#DRIVER=./fds_driver.tar.gz
DRIVER_DIR=$PWD
BIN_DIR=/usr/sbin

echo "copy cinder files to $CINDER_DRIVER_DIR"

if [ ! -d "$CINDER_DRIVER_DIR" ]; then
    echo "Error: cinder volume drivers directory does not exist."
    echo "$CINDER_DRIVER"
    exit 1
fi

if [ ! -e $DRIVER_DIR/nbdadm.py ]; then
    echo "nbdadm.py not exist"
    exit 1
fi
cp $DRIVER_DIR/nbdadm.py $BIN_DIR/

cp -rf $DRIVER_DIR/fds_api $CINDER_DRIVER_DIR
cp -f $DRIVER_DIR/fds_common.py $CINDER_DRIVER_DIR
cp -f $DRIVER_DIR/fdsnbdd_juno.py $CINDER_DRIVER_DIR

## Cinder volume filter

VOLUME_FILTERS=/etc/cinder/rootwrap.d/volume.filters
if [ -e $VOLUME_FILTERS ]; then
    found=`cat $VOLUME_FILTERS | grep -c "nbdadm.py"`
    if [ $found -eq 0 ]; then
        echo "nbdadm.py: CommandFilter, nbdadm.py, root" >> $VOLUME_FILTERS
    fi
fi

##  Appending FDS configuration to cinder.conf

CINDER_CFG=/etc/cinder/cinder.conf
CINDER_FDS_CFG=$PWD/cinder_fds_cfg_append.txt

cp $CINDER_CFG ${CINDER_CFG}_`date +%F-%H-%M-%S`
cat $CINDER_CFG | grep "^[^#]*enabled_backends=[^#]*fds"
if [ $? -eq 0 ]; then
    echo "cinder cfg already setup"
    echo "restarting cinder"
    service cinder-volume restart
    exit 0
else
    ## no fds found 
    cat $CINDER_CFG | \
        sed 's/\(enabled_backends=\)/enabled_backends=fds,/' > /tmp/cinder.conf
    cat $CINDER_FDS_CFG >> /tmp/cinder.conf

    cp -f /tmp/cinder.conf /etc/cinder/cinder.conf
fi

service cinder-volume restart
source ./openrc.sh

## Create FDS volume type for Cinder
cinder --os-username admin --os-tenant-name admin type-create fds
cinder --os-username admin --os-tenant-name admin type-key fds set volume_backend_name=FDS
cinder --os-username admin --os-tenant-name admin extra-specs-list
